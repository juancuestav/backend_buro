<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PuestoOcupacion extends Model
{
    use HasFactory;

    protected $table = 'admin_registro_civil_puestos_ocupaciones';
}
