<?php

function priceFormat($value)
{
	return number_format($value, 2, '.', ',');
}
