<?php
return [
'id' => '',
'porcentaje_iva' => '12' ,
'admite_pago_efectivo' => 'NO ACTIVO' ,
'admite_pago_tarjeta' => 'ACTIVO' ,
'admite_deposito_bancario' => 'ACTIVO' ,
'url_pago_tarjeta' => 'https://www.google.com' ,
'numero_cuenta' => '11' ,
'entidad_financiera' => '22' ,
'propietario_cuenta' => '33' ,
'identificacion_propietario_cuenta' => '44' ,
'numero_contacto' => '458' ,
'whatsapp' => 'editado otra vez' ,
'facebook' => 'nuevo feibu' ,
'instagram' => 'dfg' ,
'twitter' => 'dfg' ,
];
