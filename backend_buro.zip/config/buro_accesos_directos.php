<?php
return [
'porcentaje_iva' => '12' ,
'admite_pago_efectivo' => 'NO ACTIVO' ,
'admite_pago_tarjeta' => 'ACTIVO' ,
'admite_deposito_bancario' => 'ACTIVO' ,
'url_pago_tarjeta' => 'https://www.google.com' ,
'numero_cuenta' => '',
'entidad_financiera' => '',
'propietario_cuenta' => '',
'identificacion_propietario_cuenta' => '',
'numero_contacto' => '',
'whatsapp' => '56456454' ,
'facebook' => 'https://www.facebook.com/jbcv9999/' ,
'instagram' => 'instagram' ,
'twitter' => 'twitter' ,
];
