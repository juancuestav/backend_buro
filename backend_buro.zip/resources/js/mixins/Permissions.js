export default function can(permissionName) {
    return Permissions.indexOf(permissionName) !== -1
}
