export const configuracionColumnas = [
    {
        title: "Fecha",
        field: "fecha",
        vertAlign: "middle",
    },
    {
        title: "Mensaje",
        field: "mensaje",
        vertAlign: "middle",
    },
]
