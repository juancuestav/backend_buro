export class GraficaDatos {
    etiqueta: string
    valor: number

    constructor() {
        this.etiqueta = ""
        this.valor = 0
    }
}
