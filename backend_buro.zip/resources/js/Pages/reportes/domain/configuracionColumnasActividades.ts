export const configuracionColumnasActividades = [
    {
        title: "Actividad económica principal",
        field: "actividad",
        headerSort: false,
        editor: "input",
        minWidth: 800,
        /* editorParams: {
            autocomplete: "true",
            allowEmpty: false,
            listOnEmpty: true,
            valuesLookup: true,
            values: tiposActividadesEconomicas,
        }, */
    },
]
