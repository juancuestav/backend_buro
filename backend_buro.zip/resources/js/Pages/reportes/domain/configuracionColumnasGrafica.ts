export const configuracionColumnasGrafica = [
    {
        title: "Etiqueta",
        field: "etiqueta",
        headerSort: false,
        editor: "input",
        minWidth: 200,
    },
    {
        title: "Valor",
        field: "valor",
        headerSort: false,
        editor: "input",
    },
]
