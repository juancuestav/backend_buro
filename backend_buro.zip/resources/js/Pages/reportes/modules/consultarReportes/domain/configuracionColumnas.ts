export const configuracionColumnas = [
    {
        title: "ID",
        field: "id",
        vertAlign: "middle",
    },
    {
        title: "Nombre",
        field: "nombre",
        vertAlign: "middle",
    },
    {
        title: "Ruta",
        field: "ruta",
        visible: false,
        vertAlign: "middle",
    },
]
