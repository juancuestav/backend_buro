export class ItemMiReporte {
    id: number | null
    nombre: string
    ruta: string

    constructor() {
        this.id = null
        this.nombre = ""
        this.ruta = ""
    }
}
