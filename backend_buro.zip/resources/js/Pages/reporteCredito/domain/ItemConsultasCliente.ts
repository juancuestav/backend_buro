export class ItemConsultasCliente {
    mes: string
    entidad_financiera: string

    constructor() {
        this.mes = ""
        this.entidad_financiera = ""
    }
}
