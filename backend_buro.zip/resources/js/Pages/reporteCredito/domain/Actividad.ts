export class Actividad {
    actividad: string

    constructor() {
        this.actividad = ""
    }
}
