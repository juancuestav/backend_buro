export class ItemSeguro {
    seguro: string
    tipo_seguro: string
    mensaje: string
    cobertura_atencion: string

    constructor() {
        this.seguro = ""
        this.tipo_seguro = ""
        this.mensaje = ""
        this.cobertura_atencion = ""
    }
}
