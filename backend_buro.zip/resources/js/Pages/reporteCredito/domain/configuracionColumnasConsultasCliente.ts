export const configuracionColumnasConsultasCliente = [
    {
        name: "mes",
        field: "mes",
        label: "Mes",
        align: "left",
    },
    {
        name: "entidad_financiera",
        field: "entidad_financiera",
        label: "Entidad financiera",
        align: "left",
    },
]
