export const configuracionColumnasActividades = [
    {
        name: "actividad",
        field: "actividad",
        label: "Actividad económica principal",
        align: "left",
    },
]
