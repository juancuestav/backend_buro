export class Establecimiento {
    establecimiento: string
    nombre_comercial: string
    ubicacion: string
    estado: string

    constructor() {
        this.establecimiento = ""
        this.nombre_comercial = ""
        this.ubicacion = ""
        this.estado = ""
    }
}
