export class Marketing {
    nombre: string | null
    apellidos: string | null
    edad: string | null
    provincia: string | null
    ciudad: string | null
    correo: string | null
    direccion: string | null
    celular: string | null
    tipo_identificacion: string | null
    identificacion: string | null

    constructor() {
        this.nombre = null
        this.apellidos = null
        this.edad = null
        this.provincia = null
        this.ciudad = null
        this.correo = null
        this.direccion = null
        this.celular = null
        this.tipo_identificacion = null
        this.identificacion = null
    }
}
