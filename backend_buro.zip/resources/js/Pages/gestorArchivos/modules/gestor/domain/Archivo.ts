export class Archivo {
    id: number | null
    nombre: string | null
    carpeta: number | null
    tamanio_bytes: number | null
    ruta: string | null

    constructor() {
        this.id = null
        this.nombre = null
        this.carpeta = null
        this.tamanio_bytes = null
        this.ruta = null
    }
}
