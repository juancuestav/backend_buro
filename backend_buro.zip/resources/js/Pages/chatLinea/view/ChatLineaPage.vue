<template>
    <sidebar-layout>
        <h1 class="fs-4 fw-bold text-center mb-4">Chat en línea</h1>
        <p class="text-center">
        <div id="boton-whatsapp"></div>

            <!-- <button class="btn btn-success text-white">
                <i class="bi-whatsapp me-2"></i>
                Iniciar chat
            </button> -->
        </p>
    </sidebar-layout>
</template>

<script src="./ChatLineaPage.ts"></script>
