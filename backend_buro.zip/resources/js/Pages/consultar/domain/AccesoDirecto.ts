export class AccesoDirecto {
    nombre_acceso: string
    url: string

    constructor() {
        this.nombre_acceso = ""
        this.url = ""
    }
}
