export const configuracionColumnas = [
    {
        title: "Tiempo",
        field: "tiempo",
        sorter: "string",
        width: 200,
    },
    {
        title: "Cliente",
        field: "cliente",
        sorter: "string",
        width: 200,
    },
]
